<?php
declare(strict_types=1);
require 'config.php'; // initializes $mysqli and session environment

// --- Start session if not already started ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// --- Auth check ---
if (!isset($_SESSION['user_id'], $_SESSION['role'])) {
    header('Location: login.php');
    exit;
}

// --- CSRF protection ---
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
function csrf_check(?string $token): bool {
    return is_string($token) && hash_equals($_SESSION['csrf_token'], $token);
}

// --- Only allow POST + file upload ---
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_FILES['file'])) {
    header('Location: dashboard.php');
    exit;
}

$token = $_POST['csrf_token'] ?? '';
if (!csrf_check($token)) {
    http_response_code(400);
    exit('Invalid CSRF token.');
}

// --- Validate user and role ---
$userId = (int)$_SESSION['user_id'];
$isAdmin = ($_SESSION['role'] === 'admin');

// --- Ensure the session user actually exists in the users table ---
$check = $mysqli->prepare('SELECT id FROM users WHERE id = ?');
if (! $check) {
    error_log('DB error (prepare user check): ' . $mysqli->error);
    http_response_code(500);
    exit('Server error.');
}
$check->bind_param('i', $userId);
if (! $check->execute()) {
    error_log('DB error (execute user check): ' . $check->error);
    http_response_code(500);
    exit('Server error.');
}
$check->store_result();
if ($check->num_rows === 0) {
    // This is the root cause of the foreign key failure: session user_id does not exist in users table
    $check->close();
    error_log('Upload denied: session user_id ' . $userId . ' not found in users table.');
    http_response_code(403);
    exit('Upload denied: your account was not found. Please log in or register.');
}
$check->close();

// --- Directory setup ---
$uploadDir = __DIR__ . '/uploads/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// --- File validation ---
$file = $_FILES['file'];
$maxSize = 5 * 1024 * 1024; // 5MB limit

if ($file['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    exit('File upload error. Try again.');
}

if ($file['size'] > $maxSize) {
    http_response_code(400);
    exit('File too large (max 5MB).');
}

// Sanitize the original filename
$originalName = basename($file['name']);
$sanitizedName = preg_replace('/[^A-Za-z0-9._-]/', '_', $originalName);

// Prevent overwriting: generate unique filename (this will be the stored/encrypted filename)
$uniqueName = sprintf('%s_%s', time(), $sanitizedName);
$targetPath = $uploadDir . $uniqueName;

// Optional: restrict allowed MIME types
$allowedTypes = [
    'image/jpeg', 'image/png', 'image/gif',
    'application/pdf', 'text/plain'
];
$finfo = new finfo(FILEINFO_MIME_TYPE);
$mimeType = $finfo->file($file['tmp_name']);
if (!in_array($mimeType, $allowedTypes, true)) {
    http_response_code(400);
    exit('Unsupported file type.');
}

// --- Read uploaded file data and encrypt before writing to disk ---
$tmpPath = $file['tmp_name'];
$data = file_get_contents($tmpPath);
if ($data === false) {
    http_response_code(500);
    exit('Failed to read uploaded file.');
}

// AES-256-GCM encryption
$cipher = 'aes-256-gcm';
$ivLen = openssl_cipher_iv_length($cipher);
$iv = random_bytes($ivLen);
$tag = '';
$ciphertext = openssl_encrypt($data, $cipher, MASTER_KEY, OPENSSL_RAW_DATA, $iv, $tag);
if ($ciphertext === false) {
    http_response_code(500);
    exit('Encryption failed.');
}

// Write ciphertext to storage (overwrite targetPath)
if (file_put_contents($targetPath, $ciphertext) === false) {
    http_response_code(500);
    exit('Failed to store encrypted file.');
}

// --- Store metadata in database ---
// Save original display name in `filename`, the stored filename in `filepath`, and store iv/tag (base64)
$iv_b64 = base64_encode($iv);
$tag_b64 = base64_encode($tag);

$stmt = $mysqli->prepare('INSERT INTO files (user_id, filename, filepath, iv, tag, created_at) VALUES (?, ?, ?, ?, ?, NOW())');
if (!$stmt) {
    // DEV DEBUG: log and show DB error to help debugging locally.
    $dberr = $mysqli->error;
    error_log('DB error (prepare): ' . $dberr);
    http_response_code(500);
    exit('Server error (DB prepare): ' . htmlspecialchars($dberr, ENT_QUOTES));
}
$displayName = $originalName; // what user sees
$storedPath = $uniqueName;    // actual file stored in uploads/
$stmt->bind_param('issss', $userId, $displayName, $storedPath, $iv_b64, $tag_b64);
if (! $stmt->execute()) {
    // DEV DEBUG: log and show DB execute error
    $stmtErr = $stmt->error;
    error_log('DB execute error: ' . $stmtErr);
    http_response_code(500);
    exit('Server error (DB execute): ' . htmlspecialchars($stmtErr, ENT_QUOTES));
}
$stmt->close();

// --- Redirect to dashboard after success ---
header('Location: dashboard.php');
exit;
